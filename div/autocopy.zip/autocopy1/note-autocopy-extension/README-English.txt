Temporary installation guide (while Chrome Web Store approval is pending)

1. Download the extension .zip file.
2. Extract the .zip so you get a normal folder.
3. In Chrome, open "chrome://extensions"(paste into URL and enter)
4. Turn on Developer mode in the top-right corner.
5. Click Load unpacked.
6. Select the extracted extension folder.
7. Refresh the Transcribe Notes page.
8. In the app, choose Auto-copy mode:
   - Transcript, or
   - Note

After that, finished transcripts or finished notes can be copied automatically to your clipboard, depending on the selected mode.

Important

- Off = no automatic copying
- Transcript = auto-copy when transcription is finished
- Note = auto-copy when note generation is finished
- Manual Copy buttons in the app can still be used at any time

Notifications in Windows

To receive the Chrome pop-up notification when copying is complete, notifications must be allowed both by Windows and by Chrome. If either one blocks notifications, the pop-up may not appear.

In Windows, go to:
Settings -> System -> Notifications

In Chrome, make sure notifications are allowed for the relevant site under:
Settings -> Privacy and security -> Site settings -> Notifications

Also check that Do Not Disturb / Focus Assist is turned off or allows Chrome.

What's new in 1.3.0

- The Redactor's Autocopy checkbox is now supported. After redaction is
  complete, the redacted transcript is copied and the existing desktop
  notification is shown.
- Redactor Autocopy is independent of the shared Off / Transcript / Note
  selector. Turning off the Redactor checkbox disables both its copy and its
  notification.

What's new in 1.4.0

- Auto-copy now runs inside every preset workspace, not only the first preset.
- Both tn-beta.netlify.app and scottyboa.github.io are supported.
- If an older unpacked version is already installed, remove it or reload the
  newly extracted 1.4.0 folder from chrome://extensions.

What's new in 1.2.0

- The mini panel now has a small "jump to tab" button below the close
  (X) button. Clicking it brings the Chrome tab that is currently
  selected in the mini panel to the foreground - even if Chrome is
  minimized or behind another program. This requires the extension to
  be installed; the rest of the mini panel works without it.
- New "tabs" permission is needed for the jump-to-tab feature.
  Auto-copy behavior is unchanged.
