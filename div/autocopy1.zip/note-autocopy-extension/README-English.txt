Temporary installation guide (while Chrome Web Store approval is pending)

1. Download the extension .zip file.
2. Extract the .zip so you get a normal folder.
3. In Chrome, open "chrome://extensions"(paste into URL and enter)
4. Turn on Developer mode in the top-right corner.
5. Click Load unpacked.
6. Select the extracted extension folder.
7. Refresh the Transcribe Notes page.
8. Turn on Auto-copy in the app.

After that, finished notes can be copied automatically to your clipboard, and you can paste them with Ctrl + V.

Notifications in Windows

To receive the Chrome pop-up notification when copying is complete, notifications must be allowed both by Windows and by Chrome. If either one blocks notifications, the pop-up may not appear.

In Windows, go to:
Settings -> System -> Notifications

Make sure:
- Notifications are turned on
- Google Chrome is allowed to send notifications

In Chrome, make sure notifications are allowed for the relevant site under:
Settings -> Privacy and security -> Site settings -> Notifications

Also check that Do Not Disturb / Focus Assist is turned off or allows Chrome.
