Temporary installation guide (while Chrome Web Store approval is pending)

1. Download the extension .zip file.
2. Extract the .zip so you get a normal folder.
3. In Chrome, open "chrome://extensions"(paste into URL and enter)
4. Turn on Developer mode in the top-right corner.
5. Click Load unpacked.
6. Select the extracted extension folder.
7. Refresh the Transcribe Notes page.
8. In the app, choose Auto-copy mode:
   - Transcript, or
   - Note

After that, finished transcripts or finished notes can be copied automatically to your clipboard, depending on the selected mode.

Important

- Off = no automatic copying
- Transcript = auto-copy when transcription is finished
- Note = auto-copy when note generation is finished
- Manual Copy buttons in the app can still be used at any time

Notifications in Windows

To receive the Chrome pop-up notification when copying is complete, notifications must be allowed both by Windows and by Chrome. If either one blocks notifications, the pop-up may not appear.

In Windows, go to:
Settings -> System -> Notifications

In Chrome, make sure notifications are allowed for the relevant site under:
Settings -> Privacy and security -> Site settings -> Notifications

Also check that Do Not Disturb / Focus Assist is turned off or allows Chrome.
