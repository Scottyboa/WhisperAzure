function isAutoCopyEnabled() {
  try {
    const checkbox =
      document.getElementById("autoCopyFinishedNoteToggle") ||
      document.querySelector('input[id*="autoCopy"][type="checkbox"]');

    if (checkbox) {
      return checkbox.checked === true;
    }

    return window.localStorage.getItem("autoCopyFinishedNote") === "true";
  } catch (err) {
    console.warn("[AutoCopyExt] Could not determine auto-copy state:", err);
    return false;
  }
}

function getGeneratedNoteField() {
  return document.getElementById("generatedNote");
}

function getGeneratedNoteText() {
  const field = getGeneratedNoteField();
  if (!field) return "";

  if (typeof field.value === "string") {
    return field.value.trim();
  }

  return (field.textContent || "").trim();
}

function hasUsableExtensionRuntime() {
  return !!(typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.id);
}

function sendRuntimeMessageSafe(payload, label) {
  return new Promise((resolve) => {
    if (!hasUsableExtensionRuntime()) {
      console.warn(`[AutoCopyExt] ${label} skipped: extension runtime unavailable.`);
      resolve({ ok: false, error: "Extension runtime unavailable." });
      return;
    }

    try {
      chrome.runtime.sendMessage(payload, (response) => {
        const err = chrome.runtime?.lastError;
        if (err) {
          console.warn(`[AutoCopyExt] ${label} failed:`, err.message);
          resolve({ ok: false, error: err.message });
          return;
        }

        resolve(response || { ok: true });
      });
    } catch (err) {
      console.warn(`[AutoCopyExt] ${label} failed:`, err);
      resolve({ ok: false, error: err?.message || String(err) });
    }
  });
}

let lastCopiedText = "";
let lastCopiedAt = 0;
let pendingTimer = null;

function shouldSuppressDuplicateCopy(noteText) {
  const now = Date.now();
  const isDuplicateBurst =
    noteText === lastCopiedText && now - lastCopiedAt < 2000;

  if (isDuplicateBurst) {
    return true;
  }

  lastCopiedText = noteText;
  lastCopiedAt = now;
  return false;
}

async function requestExtensionCopy(text, sourceEvent) {
  const response = await sendRuntimeMessageSafe(
    {
      type: "COPY_TEXT",
      text,
      sourceEvent
    },
    "requestExtensionCopy"
  );

  if (!response?.ok) {
    throw new Error(response?.error || "Extension copy request failed.");
  }

  return true;
}

function waitForNoteText({ eventName, maxAttempts = 20, intervalMs = 250 }) {
  let attempts = 0;

  const tick = async () => {
    const noteText = getGeneratedNoteText();

    if (noteText) {
      if (shouldSuppressDuplicateCopy(noteText)) {
        console.log(
          `[AutoCopyExt] Suppressed duplicate auto-copy for ${eventName}`
        );
        return;
      }

      try {
        await requestExtensionCopy(noteText, eventName);
        console.log("[AutoCopyExt] copied finished note via offscreen document");
      } catch (err) {
        console.error("[AutoCopyExt] Extension copy request failed:", err);
      }

      return;
    }

    attempts += 1;
    if (attempts < maxAttempts) {
      pendingTimer = setTimeout(tick, intervalMs);
    } else {
      console.warn("[AutoCopyExt] Finished event fired, but generatedNote stayed empty.");
    }
  };

  tick();
}

function handleFinishedEvent(eventName, event) {
  try {
    const detail = event?.detail || {};

    if (detail.aborted === true) return;
    if (!isAutoCopyEnabled()) return;

    if (pendingTimer) {
      clearTimeout(pendingTimer);
      pendingTimer = null;
    }

    waitForNoteText({
      eventName,
      maxAttempts: 20,
      intervalMs: 250
    });
  } catch (err) {
    console.error(`[AutoCopyExt] ${eventName} handler failed:`, err);
  }
}

function resetGenerationState(eventName) {
  if (pendingTimer) {
    clearTimeout(pendingTimer);
    pendingTimer = null;
  }

  console.log(`[AutoCopyExt] Reset state on ${eventName}`);
}

window.addEventListener("note:finished", (event) => {
  handleFinishedEvent("note:finished", event);
});

window.addEventListener("note-generation-finished", (event) => {
  handleFinishedEvent("note-generation-finished", event);
});

// Optional reset hooks if your app emits start events.
window.addEventListener("note:started", () => {
  resetGenerationState("note:started");
});

window.addEventListener("note-generation-started", () => {
  resetGenerationState("note-generation-started");
});

console.log("[AutoCopyExt] content-script loaded", location.href);