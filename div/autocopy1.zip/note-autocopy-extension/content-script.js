function getAutoCopyMode() {
  try {
    const select = document.getElementById("autoCopyModeSelect");
    const raw =
      (select && typeof select.value === "string" ? select.value : "") ||
      window.localStorage.getItem("auto_copy_mode") ||
      "off";

    const mode = String(raw).trim().toLowerCase();
    if (mode === "off" || mode === "transcript" || mode === "note") {
      return mode;
    }

    return "off";
  } catch (err) {
    console.warn("[AutoCopyExt] Could not determine auto-copy mode:", err);
    return "off";
  }
}

function getTextFromField(fieldId) {
  const field = document.getElementById(fieldId);
  if (!field) return "";

  if (typeof field.value === "string") {
    return field.value.trim();
  }

  return (field.textContent || "").trim();
}

function getGeneratedNoteText() {
  return getTextFromField("generatedNote");
}

function getTranscriptText() {
  return getTextFromField("transcription");
}

function getFullTranscriptText() {
  const field = document.getElementById("transcription");
  if (!field) return "";

  if (typeof field.value === "string") {
    return field.value;
  }

  return field.textContent || "";
}

function hasUsableExtensionRuntime() {
  return !!(typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.id);
}

function sendRuntimeMessageSafe(payload, label) {
  return new Promise((resolve) => {
    if (!hasUsableExtensionRuntime()) {
      console.warn(`[AutoCopyExt] ${label} skipped: extension runtime unavailable.`);
      resolve({ ok: false, error: "Extension runtime unavailable." });
      return;
    }

    try {
      chrome.runtime.sendMessage(payload, (response) => {
        const err = chrome.runtime?.lastError;
        if (err) {
          console.warn(`[AutoCopyExt] ${label} failed:`, err.message);
          resolve({ ok: false, error: err.message });
          return;
        }

        resolve(response || { ok: true });
      });
    } catch (err) {
      console.warn(`[AutoCopyExt] ${label} failed:`, err);
      resolve({ ok: false, error: err?.message || String(err) });
    }
  });
}

let lastCopiedText = "";
let lastCopiedAt = 0;
let pendingTimer = null;

function shouldSuppressDuplicateCopy(text) {
  const now = Date.now();
  const isDuplicateBurst =
    text === lastCopiedText && now - lastCopiedAt < 2000;

  if (isDuplicateBurst) {
    return true;
  }

  lastCopiedText = text;
  lastCopiedAt = now;
  return false;
}

function announceExtensionPresence() {
  try {
    window.postMessage(
      {
        type: "AUTO_COPY_EXTENSION_PRESENT",
        source: "note-autocopy-extension",
        // Capabilities flag — pages that know about it can light up the
        // "jump to tab" button. Older pages simply ignore this field, so
        // backward compatibility is preserved.
        capabilities: ["copy", "focus-tab", "redactor-autocopy"]
      },
      window.location.origin
    );
  } catch (err) {
    console.warn("[AutoCopyExt] Could not announce extension presence:", err);
  }
}

function notifyPageCopyResult({ ok, copyKind, text, sourceEvent, reason = "", workspaceId = "" }) {
  try {
    window.postMessage(
      {
        type: "AUTO_COPY_EXTENSION_COPY_RESULT",
        source: "note-autocopy-extension",
        ok: !!ok,
        copyKind: String(copyKind || "").trim().toLowerCase() || "note",
        textLength: String(text || "").length,
        sourceEvent: String(sourceEvent || "").trim(),
        reason: String(reason || "").trim(),
        workspaceId: String(workspaceId || "")
      },
      window.location.origin
    );
  } catch (err) {
    console.warn("[AutoCopyExt] Could not notify page about copy result:", err);
  }
}

async function requestExtensionCopy(text, sourceEvent, copyKind, workspaceId = "") {
  const response = await sendRuntimeMessageSafe(
    {
      type: "COPY_TEXT",
      text,
      sourceEvent,
      copyKind,
      workspaceId
    },
    "requestExtensionCopy"
  );

  if (!response?.ok) {
    notifyPageCopyResult({
      ok: false,
      copyKind,
      text,
      sourceEvent,
      reason: response?.error || "extension-copy-failed",
      workspaceId
    });
    throw new Error(response?.error || "Extension copy request failed.");
  }

  notifyPageCopyResult({
    ok: true,
    copyKind,
    text,
    sourceEvent,
    workspaceId
  });
  return true;
}

function waitForText({
  eventName,
  copyKind,
  getText,
  maxAttempts = 20,
  intervalMs = 250
}) {
  let attempts = 0;

  const tick = async () => {
    const text = String(getText() || "").trim();

    if (text) {
      if (shouldSuppressDuplicateCopy(text)) {
        console.log(
          `[AutoCopyExt] Suppressed duplicate auto-copy for ${eventName} (${copyKind})`
        );
        return;
      }

      try {
        await requestExtensionCopy(text, eventName, copyKind);
        console.log(
          `[AutoCopyExt] copied finished ${copyKind} via offscreen document`
        );
      } catch (err) {
        console.error("[AutoCopyExt] Extension copy request failed:", err);
      }

      return;
    }

    attempts += 1;
    if (attempts < maxAttempts) {
      pendingTimer = setTimeout(tick, intervalMs);
    } else {
      console.warn(
        `[AutoCopyExt] Finished event fired, but ${copyKind} text stayed empty.`
      );
    }
  };

  tick();
}

function handleFinishedEvent(eventName, event, expectedMode, getText, copyKind) {
  try {
    const detail = event?.detail || {};
    const mode = getAutoCopyMode();

    if (detail.aborted === true) return;
    if (mode !== expectedMode) return;

    if (pendingTimer) {
      clearTimeout(pendingTimer);
      pendingTimer = null;
    }

    waitForText({
      eventName,
      copyKind,
      getText,
      maxAttempts: 20,
      intervalMs: 250
    });
  } catch (err) {
    console.error(`[AutoCopyExt] ${eventName} handler failed:`, err);
  }
}

function resetGenerationState(eventName) {
  if (pendingTimer) {
    clearTimeout(pendingTimer);
    pendingTimer = null;
  }

  console.log(`[AutoCopyExt] Reset state on ${eventName}`);
}

window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  if (!event.data || event.data.type !== "AUTO_COPY_EXTENSION_PING") return;

  announceExtensionPresence();
});

// Shared Workspaces run inside one page application rather than separate
// iframes. Their scoped runtime sends the finished text explicitly because a
// content script cannot query fields inside a page-owned Shadow DOM.
window.addEventListener("message", async (event) => {
  if (event.source !== window || event.origin !== window.location.origin) return;
  const data = event.data || {};
  if (data.type !== "AUTO_COPY_APP_EVENT") return;

  if (data.reset) {
    resetGenerationState("AUTO_COPY_APP_EVENT");
    return;
  }

  const copyKind = String(data.copyKind || "").trim().toLowerCase();
  const text = String(data.text || "");
  const sourceEvent = String(data.sourceEvent || "AUTO_COPY_APP_EVENT");
  const workspaceId = String(data.workspaceId || "");
  if (!text.trim() || !["note", "transcript"].includes(copyKind)) return;
  if (shouldSuppressDuplicateCopy(text)) return;

  try {
    await requestExtensionCopy(text, sourceEvent, copyKind, workspaceId);
  } catch (err) {
    console.error("[AutoCopyExt] Shared Workspace copy failed:", err);
  }
});

window.addEventListener("note:finished", (event) => {
  handleFinishedEvent(
    "note:finished",
    event,
    "note",
    getGeneratedNoteText,
    "note"
  );
});

window.addEventListener("note-generation-finished", (event) => {
  handleFinishedEvent(
    "note-generation-finished",
    event,
    "note",
    getGeneratedNoteText,
    "note"
  );
});

window.addEventListener("transcription:finished", (event) => {
  handleFinishedEvent(
    "transcription:finished",
    event,
    "transcript",
    getTranscriptText,
    "transcript"
  );
});

// Redactor auto-copy is controlled by its own checkbox in the app and is
// intentionally independent of the shared Off / Transcript / Note selector.
// The app fires this only after all redaction rules have finished.
window.addEventListener("redactor:autocopy", async () => {
  const text = String(getFullTranscriptText() || "");
  if (!text.trim()) return;

  try {
    await requestExtensionCopy(text, "redactor:autocopy", "transcript");
    console.log("[AutoCopyExt] copied redacted transcript via offscreen document");
  } catch (err) {
    console.error("[AutoCopyExt] Redactor auto-copy failed:", err);
  }
});

// Optional reset hooks if your app emits start events.
window.addEventListener("note:started", () => {
  resetGenerationState("note:started");
});

window.addEventListener("note-generation-started", () => {
  resetGenerationState("note-generation-started");
});

window.addEventListener("transcription:started", () => {
  resetGenerationState("transcription:started");
});

// =====================================================================
// Focus-this-tab support
// =====================================================================
//
// The page (specifically the mini-panel BroadcastChannel hub running
// inside main.js) sends a window-level "AUTO_COPY_EXTENSION_FOCUS_TAB"
// postMessage when the user clicks the small "jump to tab" button in
// the mini panel. We forward it to the service worker, which then uses
// chrome.tabs.update + chrome.windows.update to bring this exact tab to
// the foreground — even if Chrome is minimized or behind another app.
//
// This is purely additive: pages that don't know about this message
// never send it, so older versions of the app continue to work
// identically with the rest of this extension.
window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  const data = event.data;
  if (!data || data.type !== "AUTO_COPY_EXTENSION_FOCUS_TAB") return;

  if (!hasUsableExtensionRuntime()) {
    console.warn("[AutoCopyExt] FOCUS_TAB ignored: extension runtime unavailable.");
    return;
  }

  try {
    chrome.runtime.sendMessage(
      { type: "FOCUS_THIS_TAB" },
      () => {
        const err = chrome.runtime?.lastError;
        if (err) {
          console.warn("[AutoCopyExt] FOCUS_THIS_TAB failed:", err.message);
        }
      }
    );
  } catch (err) {
    console.warn("[AutoCopyExt] FOCUS_THIS_TAB dispatch failed:", err);
  }
});

announceExtensionPresence();

console.log("[AutoCopyExt] content-script loaded", location.href);
