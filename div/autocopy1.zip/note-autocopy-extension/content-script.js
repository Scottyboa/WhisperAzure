function getAutoCopyMode() {
  try {
    const select = document.getElementById("autoCopyModeSelect");
    const raw =
      (select && typeof select.value === "string" ? select.value : "") ||
      window.localStorage.getItem("auto_copy_mode") ||
      "off";

    const mode = String(raw).trim().toLowerCase();
    if (mode === "off" || mode === "transcript" || mode === "note") {
      return mode;
    }

    return "off";
  } catch (err) {
    console.warn("[AutoCopyExt] Could not determine auto-copy mode:", err);
    return "off";
  }
}

function getTextFromField(fieldId) {
  const field = document.getElementById(fieldId);
  if (!field) return "";

  if (typeof field.value === "string") {
    return field.value.trim();
  }

  return (field.textContent || "").trim();
}

function getGeneratedNoteText() {
  return getTextFromField("generatedNote");
}

function getTranscriptText() {
  return getTextFromField("transcription");
}

function hasUsableExtensionRuntime() {
  return !!(typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.id);
}

function sendRuntimeMessageSafe(payload, label) {
  return new Promise((resolve) => {
    if (!hasUsableExtensionRuntime()) {
      console.warn(`[AutoCopyExt] ${label} skipped: extension runtime unavailable.`);
      resolve({ ok: false, error: "Extension runtime unavailable." });
      return;
    }

    try {
      chrome.runtime.sendMessage(payload, (response) => {
        const err = chrome.runtime?.lastError;
        if (err) {
          console.warn(`[AutoCopyExt] ${label} failed:`, err.message);
          resolve({ ok: false, error: err.message });
          return;
        }

        resolve(response || { ok: true });
      });
    } catch (err) {
      console.warn(`[AutoCopyExt] ${label} failed:`, err);
      resolve({ ok: false, error: err?.message || String(err) });
    }
  });
}

let lastCopiedText = "";
let lastCopiedAt = 0;
let pendingTimer = null;

function shouldSuppressDuplicateCopy(text) {
  const now = Date.now();
  const isDuplicateBurst =
    text === lastCopiedText && now - lastCopiedAt < 2000;

  if (isDuplicateBurst) {
    return true;
  }

  lastCopiedText = text;
  lastCopiedAt = now;
  return false;
}

function announceExtensionPresence() {
  try {
    window.postMessage(
      {
        type: "AUTO_COPY_EXTENSION_PRESENT",
        source: "note-autocopy-extension"
      },
      window.location.origin
    );
  } catch (err) {
    console.warn("[AutoCopyExt] Could not announce extension presence:", err);
  }
}

async function requestExtensionCopy(text, sourceEvent, copyKind) {
  const response = await sendRuntimeMessageSafe(
    {
      type: "COPY_TEXT",
      text,
      sourceEvent,
      copyKind
    },
    "requestExtensionCopy"
  );

  if (!response?.ok) {
    throw new Error(response?.error || "Extension copy request failed.");
  }

  return true;
}

function waitForText({
  eventName,
  copyKind,
  getText,
  maxAttempts = 20,
  intervalMs = 250
}) {
  let attempts = 0;

  const tick = async () => {
    const text = String(getText() || "").trim();

    if (text) {
      if (shouldSuppressDuplicateCopy(text)) {
        console.log(
          `[AutoCopyExt] Suppressed duplicate auto-copy for ${eventName} (${copyKind})`
        );
        return;
      }

      try {
        await requestExtensionCopy(text, eventName, copyKind);
        console.log(
          `[AutoCopyExt] copied finished ${copyKind} via offscreen document`
        );
      } catch (err) {
        console.error("[AutoCopyExt] Extension copy request failed:", err);
      }

      return;
    }

    attempts += 1;
    if (attempts < maxAttempts) {
      pendingTimer = setTimeout(tick, intervalMs);
    } else {
      console.warn(
        `[AutoCopyExt] Finished event fired, but ${copyKind} text stayed empty.`
      );
    }
  };

  tick();
}

function handleFinishedEvent(eventName, event, expectedMode, getText, copyKind) {
  try {
    const detail = event?.detail || {};
    const mode = getAutoCopyMode();

    if (detail.aborted === true) return;
    if (mode !== expectedMode) return;

    if (pendingTimer) {
      clearTimeout(pendingTimer);
      pendingTimer = null;
    }

    waitForText({
      eventName,
      copyKind,
      getText,
      maxAttempts: 20,
      intervalMs: 250
    });
  } catch (err) {
    console.error(`[AutoCopyExt] ${eventName} handler failed:`, err);
  }
}

function resetGenerationState(eventName) {
  if (pendingTimer) {
    clearTimeout(pendingTimer);
    pendingTimer = null;
  }

  console.log(`[AutoCopyExt] Reset state on ${eventName}`);
}

window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  if (!event.data || event.data.type !== "AUTO_COPY_EXTENSION_PING") return;

  announceExtensionPresence();
});

window.addEventListener("note:finished", (event) => {
  handleFinishedEvent(
    "note:finished",
    event,
    "note",
    getGeneratedNoteText,
    "note"
  );
});

window.addEventListener("note-generation-finished", (event) => {
  handleFinishedEvent(
    "note-generation-finished",
    event,
    "note",
    getGeneratedNoteText,
    "note"
  );
});

window.addEventListener("transcription:finished", (event) => {
  handleFinishedEvent(
    "transcription:finished",
    event,
    "transcript",
    getTranscriptText,
    "transcript"
  );
});

// Optional reset hooks if your app emits start events.
window.addEventListener("note:started", () => {
  resetGenerationState("note:started");
});

window.addEventListener("note-generation-started", () => {
  resetGenerationState("note-generation-started");
});

window.addEventListener("transcription:started", () => {
  resetGenerationState("transcription:started");
});

announceExtensionPresence();

console.log("[AutoCopyExt] content-script loaded", location.href);
