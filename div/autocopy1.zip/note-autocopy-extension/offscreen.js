async function fallbackCopyText(text) {
  const textarea = document.createElement("textarea");
  textarea.value = text;
  textarea.setAttribute("readonly", "");
  textarea.style.position = "fixed";
  textarea.style.top = "-9999px";
  textarea.style.left = "-9999px";

  document.body.appendChild(textarea);
  textarea.focus();
  textarea.select();

  const ok = document.execCommand("copy");
  document.body.removeChild(textarea);

  if (!ok) {
    throw new Error("execCommand copy fallback failed.");
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== "OFFSCREEN_COPY") return;

  (async () => {
    try {
      const text = typeof message.text === "string" ? message.text : "";

      if (!text) {
        sendResponse({ ok: false, error: "No text provided." });
        return;
      }

      try {
        await navigator.clipboard.writeText(text);
      } catch (err) {
        console.warn(
          "[AutoCopyExt] navigator.clipboard.writeText failed, using fallback:",
          err
        );
        await fallbackCopyText(text);
      }

      sendResponse({ ok: true });
    } catch (err) {
      console.error("[AutoCopyExt] Clipboard write failed:", err);
      sendResponse({
        ok: false,
        error: err?.message || String(err)
      });
    }
  })();

  return true;
});

console.log("[AutoCopyExt] offscreen document loaded");