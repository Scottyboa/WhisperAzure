const OFFSCREEN_DOCUMENT_PATH = "offscreen.html";

async function showNotification(title, message) {
  try {
    const id = await chrome.notifications.create({
      type: "basic",
      iconUrl: "icons/icon128.png",
      title,
      message,
      priority: 2,
      requireInteraction: false
    });

    console.log("[AutoCopyExt] notification shown:", id, title, message);
  } catch (err) {
    console.error("[AutoCopyExt] Notification failed:", err);
  }
}

async function hasOffscreenDocument() {
  if (!chrome.runtime.getContexts) {
    return false;
  }

  const contexts = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH)]
  });

  return contexts.length > 0;
}

async function ensureOffscreenDocument() {
  const alreadyExists = await hasOffscreenDocument();

  if (alreadyExists) {
    return;
  }

  await chrome.offscreen.createDocument({
    url: OFFSCREEN_DOCUMENT_PATH,
    reasons: ["CLIPBOARD"],
    justification: "Copy finished notes to the clipboard when the app tab is not focused."
  });

  console.log("[AutoCopyExt] offscreen document created");
}

async function sendOffscreenCopy(text) {
  await ensureOffscreenDocument();

  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      {
        type: "OFFSCREEN_COPY",
        text
      },
      (response) => {
        const err = chrome.runtime?.lastError;
        if (err) {
          resolve({ ok: false, error: err.message });
          return;
        }

        resolve(response || { ok: false, error: "No response from offscreen document." });
      }
    );
  });
}

chrome.runtime.onInstalled.addListener(() => {
  console.log("[AutoCopyExt] service worker installed");
});

chrome.runtime.onStartup?.addListener(() => {
  console.log("[AutoCopyExt] service worker started");
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message) return;

  console.log("[AutoCopyExt] onMessage received:", message);

  if (message.type === "COPY_TEXT") {
    (async () => {
      try {
        const text = typeof message.text === "string" ? message.text : "";

        if (!text.trim()) {
          await showNotification(
            "Note generation completed",
            "Could not copy to clipboard."
          );
          sendResponse({ ok: false, error: "No text provided." });
          return;
        }

        const result = await sendOffscreenCopy(text);

        if (result?.ok) {
          await showNotification(
            "Note generation completed",
            "Copied to clipboard."
          );
          sendResponse({ ok: true });
          return;
        }

        await showNotification(
          "Note generation completed",
          "Could not copy to clipboard."
        );

        sendResponse({
          ok: false,
          error: result?.error || "Clipboard copy failed."
        });
      } catch (err) {
        console.error("[AutoCopyExt] COPY_TEXT failed:", err);

        try {
          await showNotification(
            "Note generation completed",
            "Could not copy to clipboard."
          );
        } catch (_) {}

        sendResponse({
          ok: false,
          error: err?.message || String(err)
        });
      }
    })();

    return true;
  }
});