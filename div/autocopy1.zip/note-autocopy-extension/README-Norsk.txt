Midlertidig installasjonsguide (mens Chrome Web Store-godkjenning pågår)

1. Last ned utvidelsens .zip-fil.
2. Pakk ut .zip-filen slik at du får en vanlig mappe.
3. I Chrome åpner du "chrome://extensions"(lim inn i URL og trykk enter)
4. Slå på Developer mode øverst til høyre.
5. Klikk Load unpacked.
6. Velg den utpakkede utvidelsesmappen.
7. Oppdater Transcribe Notes-siden.
8. Slå på Auto-copy i appen.

Etter dette kan ferdige notater kopieres automatisk til utklippstavlen, og du kan lime dem inn med Ctrl + V.

Varsler i Windows

For å få Chrome-varslet når kopieringen er fullført, må varsler være tillatt både i Windows og i Chrome. Hvis én av dem blokkerer varsler, kan popup-varslet utebli.

I Windows går du til:
Innstillinger -> System -> Varsler

Kontroller at:
- Varsler er slått på
- Google Chrome har tillatelse til å sende varsler

I Chrome må varsler være tillatt for det aktuelle nettstedet under:
Innstillinger -> Personvern og sikkerhet -> Nettstedsinnstillinger -> Varsler

Kontroller også at Ikke forstyrr / Fokusassistent er slått av eller tillater Chrome.
